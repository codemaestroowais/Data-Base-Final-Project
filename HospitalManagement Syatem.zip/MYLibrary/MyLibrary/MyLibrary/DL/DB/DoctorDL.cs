﻿using MyLibrary.BL;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.DL.DB
{
    public class DoctorDL : IDoctor
    {
        private string conn; 
        public DoctorDL(string conn)
        {
            this.conn = conn;
        }

        public bool AddDoctor(DoctorBL doctor)
        {
            string status = "Not Selected";
            string query = String.Format("Insert into Doctor(Name, Speciality, Status) values('{0}','{1}','{2}')"
                , doctor.GetDoctorName(), doctor.GetDoctorSpeciality(), status);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public List<DoctorBL> ViewDoctor()
        {
            List<DoctorBL> employ = new List<DoctorBL>();
            string query = "Select * from Doctor";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                DoctorBL doctor1 = new DoctorBL(Convert.ToString(reader["Name"]), Convert.ToString(reader["Speciality"]));
                employ.Add(doctor1);
            }
            reader.Close();
            sqlConnection.Close();
            return employ;
        }
        public DoctorBL GetDoctorName(string name)
        {
            string query = String.Format("Select * from Doctor where Name='{0}'", name);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            if (reader.Read())
            {
                DoctorBL doctor = new DoctorBL(Convert.ToString(reader["Name"]), Convert.ToString(reader["Speciality"]));
                reader.Close();
                sqlConnection.Close();
                return doctor;
            }
            reader.Close();
            sqlConnection.Close();
            return null;
        }
        public bool UpdateDoctor(string PatientCNIC, DoctorBL doctor)
        {
            string query = String.Format("Update Doctor set Name = '{0}',Speciality = '{1}' " + " where Name = '{0}'", doctor.GetDoctorName(), doctor.GetDoctorSpeciality());
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public bool SelectDoctor(string doctorname, string doctorspeciality, string Date, string gmail)
        {
            string status = "Selected";
            string query = String.Format("Insert into SelectedDoctors(Name, Speciality, Status, Date, Gmail) values('{0}','{1}','{2}', '{3}','{4}')"
                , doctorname, doctorspeciality, status, Date, gmail);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public bool RemoveDoctor(string doctorName, string doctorSpeciality)
        {
            string query = String.Format("Delete from Doctor where Name ='{0}' and Speciality ='{1}'", doctorName, doctorSpeciality);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            int rows = sql.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public bool RemoveSelectedDoctor(string Date)
        {
            string query = String.Format("Delete from SelectedDoctors where Date < '{0}'", Date);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            int rows = sql.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public (List<DoctorBL>, List<string>) ViewSelectedDoctor(string gmail, string date1)
        {
            RemoveSelectedDoctor(date1);
            List<string> date=new List<string>();
            List<DoctorBL> employ = new List<DoctorBL>();
            string query = string.Format("Select * from SelectedDoctors where Gmail = '{0}' and Date >= '{1}'", gmail, date1);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                DoctorBL doctor1 = new DoctorBL(Convert.ToString(reader["Name"]), Convert.ToString(reader["Speciality"]), Convert.ToString(reader["Status"]));
                employ.Add(doctor1);
                date.Add(Convert.ToString(reader["Date"]));

            }
            reader.Close();
            sqlConnection.Close();
            return (employ, date);
        }
    }
}
