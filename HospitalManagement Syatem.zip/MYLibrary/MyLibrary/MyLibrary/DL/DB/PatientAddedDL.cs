﻿using MyLibrary.BL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLibrary.DL_Interface;

namespace MyLibrary.DL.DB
{
    public class PatientAddedDL : IPatientAdded
    {
        private string conn = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        public PatientAddedDL()
        {
            
        }
        public bool AddPatient(PatientAdded patient)
        {
            string query = String.Format("Insert into PatientAdded2(Name,Age,CNIC, PhoneNo, MedicleHistory) values('{0}','{1}','{2}','{3}','{4}')"
                , patient.GetPatientName(), patient.GetPatientAge(), patient.GetPatientCNIC(), patient.GetPatientPhoneNo(), patient.GetPatientHistory());
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public List<PatientAdded> ViewPatient()
        {
            List<PatientAdded> patient = new List<PatientAdded>();
            string query = "Select * from PatientAdded2";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                PatientAdded patient1 = new PatientAdded(Convert.ToString(reader["Name"]), Convert.ToInt32(reader["Age"]), Convert.ToString(reader["CNIC"]), Convert.ToString(reader["PhoneNo"]), Convert.ToString(reader["MedicleHistory"]));
                patient.Add(patient1);
            }
            reader.Close();
            sqlConnection.Close();
            return patient;
        }
        public PatientAdded GetPatient(string CNIC)
        {
            string query = String.Format("Select * from PatientAdded2 where CNIC='{0}'", CNIC);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            if (reader.Read())
            {
                PatientAdded patient = new PatientAdded(Convert.ToString(reader["Name"]), Convert.ToInt32(reader["Age"]), Convert.ToString(reader["CNIC"]), Convert.ToString(reader["PhoneNo"]), Convert.ToString(reader["MedicleHistory"]));
                reader.Close();
                sqlConnection.Close();
                return patient;
            }
            reader.Close();
            sqlConnection.Close();
            return null;
        }
        public bool UpdatePatient(string PatientCNIC, PatientAdded patient)
        {
            string query = String.Format("Update PatientAdded2 set Name = '{0}',Age = '{1}',CNIC='{2}',PhoneNo='{3}',MedicleHistory='{4}'" +
                " where CNIC = '{5}'", patient.GetPatientName(), patient.GetPatientAge(), patient.GetPatientCNIC(), patient.GetPatientPhoneNo(), patient.GetPatientHistory(), PatientCNIC);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public bool RemovePatient(string PatientCNIC)
        {
            string query = String.Format("Delete from PatientAdded2 where CNIC ='{0}'", PatientCNIC);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            int rows = sql.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
    }
}
