﻿using MyLibrary.BL;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.DL.DB
{
    public class EmplyDL : IEmply
    {
        private string conn = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        public EmplyDL(string conn)
        {
            this.conn = conn;
        }
        public bool AddEmploy(EmplyBL employ)
        {
            string conn = Utilitys.Utility.GetConnectionString();
            string query = String.Format("Insert into Employ(Name, Gender) values('{0}','{1}')"
                , employ.GetEmployName(), employ.GetEmployGender());
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public List<EmplyBL> GetEmploys()
        {
            List<EmplyBL> employ = new List<EmplyBL>();
            string conn = Utilitys.Utility.GetConnectionString();
            string query = "Select * from Employ";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                EmplyBL employ1 = new EmplyBL(Convert.ToString(reader["Name"]), Convert.ToString(reader["Gender"]));
                employ.Add(employ1);
            }
            reader.Close();
            sqlConnection.Close();
            return employ;
        }
    }
}
