﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLibrary.BL;
using MyLibrary.DL_Interface;
using MyLibrary.Utilitys;

namespace MyLibrary.DL.DB
{
    public class AdminDL : IAdmin
    {
        private string conn;
        public AdminDL(string conn)
        {
            this.conn = conn;
        }
        public bool AddBed(int bed, string username)
        {
            string query = String.Format("Insert into AdminInfo(Bed, UserName) values('{0}','{1}')"
                , bed, username);
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public int GetBeds(string UserName)
        {
            string BedString = null;
            int Shops = 0;
            SqlConnection connection = new SqlConnection(conn);
            connection.Open();
            string searchQuery = String.Format("Select Bed from AdminInfo where UserName = '{0}'", UserName);
            SqlCommand command = new SqlCommand(searchQuery, connection);
            object data = command.ExecuteScalar();
            if (data != null)
            {
                BedString = data.ToString();
                connection.Close();
                Shops = int.Parse(BedString);
            }
            connection.Close();
            return Shops;
        }
    }
}
