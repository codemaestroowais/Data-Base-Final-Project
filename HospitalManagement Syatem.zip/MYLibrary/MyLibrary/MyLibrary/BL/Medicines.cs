﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class Medicines
    {
        //Attributes
        private string MedicineName;
        private int MedicineQuantity;
        private int MedicineBatchNo;
        //Constructor
        public Medicines() { }
        public Medicines(string medicineName, int medicineQuantity, int medicineBatchNo)
        {
            MedicineName = medicineName;
            MedicineQuantity = medicineQuantity;
            MedicineBatchNo = medicineBatchNo;
        }
        //Setter
        public void SetMedicineName(string MedicineName)
        {
            this.MedicineName = MedicineName;
        }
        public void SetMedicineQuantity(int MedicineQuantity)
        {
            this.MedicineQuantity = MedicineQuantity;
        }
        public void SetMedicineBatchNo(int MedicineBatchNo)
        {
            this.MedicineBatchNo = MedicineBatchNo;
        }
        //Getter
        public string GetMedicineName()
        {
            return MedicineName;
        }
        public int GetMedicineQuantity() { return MedicineQuantity; }
        public int GetMedicineBatchNo() { return MedicineBatchNo; }
    }
}
