﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class PatientReview
    {
        //Attributes
        private string ReviewPatient;
        //Constructor
        public PatientReview(string reviewPatient)
        {
            ReviewPatient = reviewPatient;
        }
        //Setter
        public void SetReviewPatient(string reviewPatient) {  ReviewPatient = reviewPatient; }
        //Getter
        public string GetReviewPatient() {  return ReviewPatient; }
    }
}
