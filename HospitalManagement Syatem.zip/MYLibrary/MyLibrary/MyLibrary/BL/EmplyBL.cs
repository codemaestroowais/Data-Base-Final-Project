﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class EmplyBL
    {
        //Attributes
        private string EmployName;
        private string EmployGender;
        //Constructor
        public EmplyBL() { }
        public EmplyBL(string employName, string employGender) { EmployName = employName; EmployGender = employGender; }
        //Setter
        public void SetEmployName(string employName) {  EmployName = employName; }
        public void SetEmployGender(string employGender) { EmployGender = employGender; }
        //Getter
        public string GetEmployName() {  return EmployName; }
        public string GetEmployGender() {  return EmployGender; }
    }
}
