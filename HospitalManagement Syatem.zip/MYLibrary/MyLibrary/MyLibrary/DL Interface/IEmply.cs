﻿using MyLibrary.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.DL_Interface
{
    public interface IEmply
    {
        //This function can add data of employ ot the database
        bool AddEmploy(EmplyBL employ);
        //This function can return the employdata list to the database
        List<EmplyBL> GetEmploys();

    }
}
