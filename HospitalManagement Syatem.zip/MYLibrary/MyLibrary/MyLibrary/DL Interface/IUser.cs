﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLibrary.BL;
namespace MyLibrary.DL_Interface
{
    public interface IUser
    {
        //This function add data of users in the database
        bool AddData(MUserBL userBL);
        // This function can check the user check the users and show the perspective forms
        MUserBL SignIn(MUserBL user);
        //This function return the list of all the users
        List<MUserBL> RetrieveData();
        //This function can check the users
        bool ValidateUser(MUserBL user);
    }
}
