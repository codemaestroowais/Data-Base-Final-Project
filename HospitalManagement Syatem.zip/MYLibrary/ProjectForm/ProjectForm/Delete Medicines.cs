﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Delete_Medicines : Form
    {
        int SelectedRow;
        static string conn = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        IMedicine medicine = new MedicineDL(conn);
        DataTable dataTable1 = new DataTable();
        public Delete_Medicines()
        {
            InitializeComponent();
            dataTable1.Columns.Add("Name");
            dataTable1.Columns.Add("Quantity");
            dataTable1.Columns.Add("Batch Number");
            List<Medicines> p;
            p = medicine.ViewMedicine();
            foreach (Medicines d in p)
            {
                dataTable1.Rows.Add(d.GetMedicineName(), d.GetMedicineQuantity(), d.GetMedicineBatchNo());
            }
            dataGridView1.DataSource = dataTable1;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pharmacist pharmacist = new Pharmacist();
            this.Hide();
            pharmacist.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
            MedicineDL p = new MedicineDL(path);
            SelectedRow = dataGridView1.CurrentCell.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[SelectedRow];
            string BatchNumber =  row.Cells[2].Value.ToString();
            int BatchNumber1 = int.Parse(BatchNumber);
            if (p.RemoveMedicine(BatchNumber1))
            {
                dataGridView1.Rows.RemoveAt(SelectedRow);
               
            }
            else
            {
                MessageBox.Show("An occured in deleting Medicine");
            }
        }

        private void Delete_Medicines_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
