﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Select_Doctor : Form
    {
        int SelectedRow=-1;
        bool check=false;
        DataTable dataTable = new DataTable();
        
        static string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        DoctorDL doctorDL = new DoctorDL(path);
        public Select_Doctor()
        {

            InitializeComponent();
            
            List<DoctorBL> list = doctorDL.ViewDoctor();
            dataTable.Columns.Add("Name");
            dataTable.Columns.Add("Speciality");
            foreach (DoctorBL doctorBL in list)
            {
                dataTable.Rows.Add(doctorBL.GetDoctorName(), doctorBL.GetDoctorSpeciality());
            }
            dataGridView1.DataSource = dataTable;
            dataGridView1.ClearSelection();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name;
            string specilatity;
            if (textBox1.Text != null)
            {

                if (check == true)
                {
                    SelectedRow = dataGridView1.CurrentCell.RowIndex;
                    if (SelectedRow >= 0)
                    {
                        DataGridViewRow row = dataGridView1.Rows[SelectedRow];
                        name = row.Cells["Name"].Value.ToString();
                        specilatity = row.Cells["Speciality"].Value.ToString();
                        doctorDL.SelectDoctor(name, specilatity, textBox1.Text, SignIn.GetUSERUSERNAME());
                        MessageBox.Show("You have been hired a doctor for your treatment.");

                    }
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            PatientMenu patientMenu = new PatientMenu();
            this.Hide();
            patientMenu.ShowDialog();
        }

        private void Select_Doctor_Load(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            check = true;
        }
    }
}
