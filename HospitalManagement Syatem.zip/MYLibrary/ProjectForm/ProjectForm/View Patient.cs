﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjectForm
{
    public partial class View_Patient : Form
    {
        IPatientAdded patient = new PatientAddedDL();
        DataTable dataTable1= new DataTable();
        int SelectedRow;
        public View_Patient()
        {
            InitializeComponent();
            dataTable1.Columns.Add("Name");
            dataTable1.Columns.Add("Age");
            dataTable1.Columns.Add("CNIC");
            dataTable1.Columns.Add("Medical History");
            dataTable1.Columns.Add("PhoneNumber");
            List<PatientAdded> p;
            p = patient.ViewPatient();
            foreach(PatientAdded d in p)
            {
                dataTable1.Rows.Add(d.GetPatientName(), d.GetPatientAge(), d.GetPatientCNIC(), d.GetPatientHistory(), d.GetPatientPhoneNo());
            }
            dataGridView1.DataSource= dataTable1;


        }

        private void button10_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            this.Hide();
            adminMenu.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PatientAdded p = patient.GetPatient(textBox1.Text);
            if (p != null)
            {
                textBox5.Text = p.GetPatientName();
                textBox2.Text = p.GetPatientAge().ToString();
                textBox3.Text = p.GetPatientCNIC();
                textBox4.Text = p.GetPatientPhoneNo();
                textBox6.Text= p.GetPatientHistory();

            }
            else
            {
                MessageBox.Show("The Patient with this CNIC is not in our record.");
            }
        }

        private void View_Patient_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            //SelectedRow = dataGridView1.CurrentCell.RowIndex;
            //if(SelectedRow >=0)
            {
                DataGridViewRow Row=null;
                PatientAdded patientAdded = new PatientAdded(textBox5.Text, int.Parse(textBox2.Text), textBox3.Text, textBox4.Text, textBox6.Text);
                if(patient.UpdatePatient(patientAdded.GetPatientCNIC(), patientAdded))
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        // Assuming the CNIC is in the first cell of each row
                        if (row.Cells[2].Value != null && row.Cells[2].Value.ToString() == textBox3.Text)
                        {
                            // Select the row if the CNIC matches
                            row.Selected = true;
                            // Optionally, you can scroll to the selected row
                            dataGridView1.FirstDisplayedScrollingRowIndex = row.Index;
                            Row = row;
                            
                            break; // Exit the loop once the row is found
                        }
                    }
                    Row.Cells[0].Value = patientAdded.GetPatientName();
                    Row.Cells[1].Value=patientAdded.GetPatientAge().ToString();
                    Row.Cells[2].Value=patientAdded.GetPatientCNIC();
                    Row.Cells[4].Value=patientAdded.GetPatientPhoneNo();
                    Row.Cells[3].Value=patientAdded.GetPatientHistory();
                }
                else
                {
                    MessageBox.Show("Unable to Update");
                }


            }
        }
    }
}
