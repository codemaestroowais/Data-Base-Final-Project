﻿using MyLibrary.DL.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyLibrary.BL;

namespace ProjectForm
{
    public partial class Update_Medicines : Form
    {
        static string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        MedicineDL medicineDL = new MedicineDL(path);
        public Update_Medicines()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {   if(textBox2.Text!=null && textBox3.Text!=null)
            {
                Medicines m = new Medicines(textBox2.Text, int.Parse(textBox3.Text), int.Parse(textBox1.Text));
                if(medicineDL.UpdateMedicine(m.GetMedicineBatchNo(), m))
                {
                    MessageBox.Show("Medicine Updated successfully");
                }
                else
                {
                    MessageBox.Show("Failed to Update");
                }
                

            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pharmacist pharmacist = new Pharmacist();
            this.Hide();
            pharmacist.ShowDialog();
        }

        private void Update_Medicines_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            Medicines medicines = medicineDL.GetMedicine(int.Parse(textBox1.Text));
            if(medicines != null)
            {
                textBox2.Text = medicines.GetMedicineName();
                textBox3.Text = medicines.GetMedicineQuantity().ToString();
            }

        }
    }
}
