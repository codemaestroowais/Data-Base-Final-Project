﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class View_Medicines : Form
    {
        public View_Medicines()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Pharmacist pharmacist = new Pharmacist();
            this.Hide();
            pharmacist.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
            int a = int.Parse(textBox1.Text);
            MedicineDL medicineDL = new MedicineDL(path);
            Medicines p = medicineDL.GetMedicine(a);
            if (p != null)
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("Name");
                dataTable.Columns.Add("Quantity");
                dataTable.Columns.Add("BatchNumber");
                dataTable.Rows.Add(p.GetMedicineName(), p.GetMedicineQuantity(), p.GetMedicineBatchNo());
                dataGridView1.DataSource = dataTable;
            }
            else
            {
                MessageBox.Show("The Medicine with this Batch Number is not in our record.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void View_Medicines_Load(object sender, EventArgs e)
        {

        }
    }
}
