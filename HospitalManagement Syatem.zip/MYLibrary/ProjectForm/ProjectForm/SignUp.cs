﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
            comboBox1.Items.Add("Male");
            comboBox1.Items.Add("Female");
            comboBox2.Items.Add("Admin");
            comboBox2.Items.Add("Patient");
            comboBox2.Items.Add("Pharmacist");
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || textBox1.Text == "" || comboBox2.Text == "" || textBox2.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Input cannot be empty.");
            }
            else
            {
                string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
                IUser user = new MUserDL(path);
                MUserBL user1 = null;
                if (comboBox2.Text == "Admin")
                {
                    IUser userCrud = new MUserDL(path);
                    user1 = new AdminBL(textBox1.Text, comboBox1.Text, textBox5.Text, textBox2.Text, comboBox2.Text);
                    AdminBL admin = (AdminBL)user1;
                    userCrud.AddData(user1);
                }
                else if (comboBox2.Text == "Patient")
                {
                    IUser userCrud = new MUserDL(path);
                    user1 = new PatientBL(textBox1.Text, comboBox1.Text, textBox5.Text, textBox2.Text, comboBox2.Text);
                    PatientBL patientBL = (PatientBL)user1;
                    userCrud.AddData(user1);
                }
                else if (comboBox2.Text == "Pharmacist")
                {
                    IUser userCrud = new MUserDL(path);
                    user1 = new PharmacistBL(textBox1.Text, comboBox1.Text, textBox5.Text, textBox2.Text, comboBox2.Text);
                    PharmacistBL pharmacistBL = (PharmacistBL)user1;
                    userCrud.AddData(user1);
                }
                bool b = user.ValidateUser(user1);
                if (b == true)
                {
                    MessageBox.Show(comboBox2.Text);
                    MessageBox.Show("The addition process of user is completed successfully");
                }
                else { MessageBox.Show("Invalid Input! User addition is uncompleted"); }
                this.Hide();
                SignIn s = new SignIn();
                this.Close();
                s.ShowDialog();
            }
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }
    }
}
 