﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class ViewSelectedDoctor : Form
    {
        static string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";

        DoctorDL doctorDL = new DoctorDL(path);
        DataTable dataTable = new DataTable();
        int SelctedRow;
        DateTime dateTime=DateTime.Now;
        public ViewSelectedDoctor()
        {
            InitializeComponent();
            string date1 = dateTime.ToString("dd-MM-yyyy");

            List<string> date;
            List<DoctorBL> list;

            (list, date) =doctorDL.ViewSelectedDoctor(SignIn.GetUSERUSERNAME(), date1);
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("Name");
            dataTable.Columns.Add("Speciality");
            dataTable.Columns.Add("Selected for Date");
            for (int i=0; i<list.Count; i++)
            {
                for(int j=0; j<date.Count; j++)
                {
                    if(i==j)
                    {
                        dataTable.Rows.Add(list[i].GetDoctorName(), list[i].GetDoctorSpeciality(), date[j]);

                    }
                }
            }
            
            dataGridView1.DataSource = dataTable;

        }

        private void ViewSelectedDoctor_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            PatientMenu patientMenu= new PatientMenu();
            this.Hide();
            patientMenu.ShowDialog();
        }
    }
}
