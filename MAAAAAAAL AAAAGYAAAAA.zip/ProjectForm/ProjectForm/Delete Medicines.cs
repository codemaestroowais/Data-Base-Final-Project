﻿using MyLibrary.DL.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Delete_Medicines : Form
    {
        public Delete_Medicines()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pharmacist pharmacist = new Pharmacist();
            this.Hide();
            pharmacist.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
            MedicineDL p = new MedicineDL(path);
            int a = int.Parse(textBox1.Text);
            if (p.RemoveMedicine(a) == true)
            {
                MessageBox.Show("The Medicine with this Batch Number has been removed from the stock.");
            }
            else
            {
                MessageBox.Show("This medicine is not in our record.");
            }
        }
    }
}
