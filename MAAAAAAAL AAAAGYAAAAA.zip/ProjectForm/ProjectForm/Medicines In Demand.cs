﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Medicines_In_Demand : Form
    {
        public Medicines_In_Demand()
        {
            InitializeComponent();
        }
    }
}
