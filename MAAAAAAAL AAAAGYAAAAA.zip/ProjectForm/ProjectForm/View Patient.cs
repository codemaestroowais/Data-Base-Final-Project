﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProjectForm
{
    public partial class View_Patient : Form
    {
        IPatientAdded patient = new PatientAddedDL();
        public View_Patient()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            this.Hide();
            adminMenu.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PatientAdded p = patient.GetPatient(textBox1.Text);
            if (p != null)
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("Name");
                dataTable.Columns.Add("Age");
                dataTable.Columns.Add("CNIC");
                dataTable.Columns.Add("PhoneNo");
                dataTable.Columns.Add("MedicleHistory");

                dataTable.Rows.Add(p.GetPatientName(), p.GetPatientAge(), p.GetPatientCNIC(), p.GetPatientPhoneNo(), p.GetPatientHistory());
                dataGridView1.DataSource = dataTable;

            }
            else
            {
                MessageBox.Show("The Patient with this CNIC is not in our record.");
            }
        }
    }
}
