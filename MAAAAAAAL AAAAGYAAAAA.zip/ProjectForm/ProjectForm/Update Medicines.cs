﻿using MyLibrary.DL.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyLibrary.BL;

namespace ProjectForm
{
    public partial class Update_Medicines : Form
    {
        public Update_Medicines()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
            MedicineDL medicineDL = new MedicineDL(path);
            int a = int.Parse(textBox1.Text);
            Medicines m = medicineDL.GetMedicine(a);
            if (m != null)
            {
                int b = int.Parse(textBox3.Text);
                Medicines m1 = new Medicines(textBox2.Text, b, a);
                medicineDL.UpdateMedicine(a, m1);
                if(medicineDL.UpdateMedicine(a, m1) == true)
                {
                    MessageBox.Show("The medicine has been updated successfully.");
                }
                else
                {
                    MessageBox.Show("The medicine is not updated.");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pharmacist pharmacist = new Pharmacist();
            this.Hide();
            pharmacist.ShowDialog();
        }
    }
}
