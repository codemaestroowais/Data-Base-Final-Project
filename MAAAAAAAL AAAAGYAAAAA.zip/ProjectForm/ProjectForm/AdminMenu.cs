﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Add_Patient add_Patient = new Add_Patient();
            this.Hide();
            add_Patient.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            View_Patient view_Patient = new View_Patient();
            this.Hide();
            view_Patient.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Update_Patient update_Patient = new Update_Patient();
            this.Hide();
            update_Patient.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Delete_Patient delete_Patient = new Delete_Patient();
            this.Hide();
            delete_Patient.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Add_Bed add_Bed = new Add_Bed();
            this.Hide();
            add_Bed.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Profit_Loss_calculation profit_Loss = new Profit_Loss_calculation();
            this.Hide();
            profit_Loss.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Add_Doctor add_Doctor = new Add_Doctor();
            this.Hide();
            add_Doctor.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            this.Hide();
            signIn.ShowDialog();
        }

        private void AdminMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
