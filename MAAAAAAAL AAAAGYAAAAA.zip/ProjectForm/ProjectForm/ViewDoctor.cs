﻿using MyLibrary.BL;
using MyLibrary.DL.DB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class ViewDoctor : Form
    {
        public ViewDoctor()
        {
            InitializeComponent();
            string path = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";

            DoctorDL doctorDL = new DoctorDL(path);
            List<DoctorBL> list = doctorDL.ViewDoctor();
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("Name");
            dataTable.Columns.Add("Speciality");
            foreach(DoctorBL doctorBL in list)
            {
                dataTable.Rows.Add(doctorBL.GetDoctorName(), doctorBL.GetDoctorSpeciality());
            }
            dataGridView1.DataSource = dataTable;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            PatientMenu patientMenu = new PatientMenu();
            this.Hide();
            patientMenu.ShowDialog(this);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }
    }
}
