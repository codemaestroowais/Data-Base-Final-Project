﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectForm
{
    public partial class Pharmacist : Form
    {
        public Pharmacist()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            View_Employ view_Employ = new View_Employ();
            this.Hide();
            view_Employ.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Add_Medicine add_Medicine = new Add_Medicine();
            this.Hide();
            add_Medicine.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            View_Medicines view_Medicines = new View_Medicines();
            this.Hide();
            view_Medicines.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Update_Medicines update_Medicines = new Update_Medicines();
            this.Hide();
            update_Medicines.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Medicines_In_Demand medicines_In_Demand = new Medicines_In_Demand();
            this.Hide();
            medicines_In_Demand.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Delete_Medicines delete_Medicines = new Delete_Medicines();
            this.Hide();
            delete_Medicines.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Add_Employ add_Employ = new Add_Employ();
            this.Hide();
            add_Employ.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            this.Hide();
            signIn.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
