﻿using MyLibrary.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyLibrary.DL.DB;

namespace ProjectForm
{
    public partial class Profit_Loss_calculation : Form
    {
        public Profit_Loss_calculation()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PatientAddedDL patientAdded = new PatientAddedDL();
            List<PatientAdded> p = patientAdded.ViewPatient();
            int m = p.Count*int.Parse(textBox1.Text) ;
            textBox2.Text = m.ToString();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenu = new AdminMenu();
            this.Hide();
            adminMenu.Show();
        }
    }
}
