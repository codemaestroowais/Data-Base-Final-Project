﻿using MyLibrary.BL;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.DL.FH
{
    public class MUserFH
    {
        public class UserFH : IUser
        {
            private static List<MUserBL> users = new List<MUserBL>();
            string path;
            public UserFH(string path)
            {
                this.path = path;
                users = RetrieveData();
            }

            public bool AddData(MUserBL user)
            {
                bool val = ValidateUser(user);
                users.Add(user);
                StreamWriter streamWriter = new StreamWriter(path, true);
                streamWriter.WriteLine(user.GetName() + "," + user.GetGender() + "," + user.GetUserName() + "," + user.GetPassword() + "," + user.GetRole());
                streamWriter.Flush();
                streamWriter.Close();
                return true;
            }

            public List<MUserBL> GetUsers()
            {
                return users;
            }
            public List<MUserBL> RetrieveData()
            {
                StreamReader streamReader = new StreamReader(path);
                if (File.Exists(path))
                {
                    string record;

                    while ((record = streamReader.ReadLine()) != null)
                    {
                        string name = GetField(record, 1);
                        string gender = GetField(record, 2);
                        string username = GetField(record, 3);
                        string password = GetField(record, 4);
                        string role = GetField(record, 5);

                        MUserBL user = new MUserBL(name, gender, username, password, role);
                        users.Add(user);
                    }
                    streamReader.Close();
                }
                return users;
            }

            public MUserBL SignIn(MUserBL user)
            {
                foreach (MUserBL storedusers in users)
                {
                    if (storedusers.GetUserName() == user.GetUserName() && storedusers.GetPassword() == user.GetPassword())
                    {
                        return storedusers;
                    }
                }
                return null;
            }

            public bool ValidateUser(MUserBL user)
            {
                for (int i = 0; i < users.Count; i++)
                {
                    if (users[i].GetUserName() == user.GetUserName() && users[i].GetPassword() == user.GetPassword())
                    {
                        return true;
                    }
                }
                return false;
            }
            private string GetField(string record, int field)
            {
                int commaCount = 1;
                string result = "";
                for (int x = 0; x < record.Count(); x++)
                {
                    if (record[x] == ',')
                    {
                        commaCount++;
                    }
                    else if (commaCount == field)
                    {
                        result += record[x];
                    }
                }
                return result;
            }
        }
    }
}
