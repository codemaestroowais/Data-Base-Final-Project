﻿using MyLibrary.BL;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLibrary.Utilitys;
using MyLibrary.DL.FH;
namespace MyLibrary.DL.DB
{
    public class MUserDL : IUser
    {
        private string conn;
        public MUserDL(string conn)
        {
            this.conn=conn;
        }
        public bool AddData(MUserBL userBL)
        {
            string query = String.Format("Insert into MUser(Name, Gender, UserName, Password, Role)" + " values('{0}','{1}','{2}','{3}','{4}')", userBL.GetName(), userBL.GetGender(), userBL.GetUserName(), userBL.GetPassword(), userBL.GetRole());
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sql = new SqlCommand(query, sqlConnection);
            int rowsaffected = sql.ExecuteNonQuery();
            sqlConnection.Close();
            if (rowsaffected > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public MUserBL SignIn(MUserBL user)
        {
            List<MUserBL> Users = RetrieveData();
            foreach (MUserBL storedusers in Users)
            {
                if (storedusers.GetUserName() == user.GetUserName() && storedusers.GetPassword() == user.GetPassword())
                {
                    return storedusers;
                }
            }
            return null;
        }
        public List<MUserBL> RetrieveData()
        {
            List<MUserBL> users = new List<MUserBL>();
            string query = "Select * from MUser ";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                MUserBL user = new MUserBL(Convert.ToString(reader["Name"]), Convert.ToString(reader["Gender"]), Convert.ToString(reader["Username"]), Convert.ToString(reader["Password"]), Convert.ToString(reader["Role"]));
                users.Add(user);
            }
            reader.Close();
            sqlConnection.Close();
            return users;
        }
        public bool ValidateUser(MUserBL user)
        {
            List<MUserBL> Users = RetrieveData();
            for (int i = 0; i < Users.Count; i++)
            {
                if (user.GetPassword() == Users[i].GetPassword() && user.GetUserName() == Users[i].GetUserName())
                { return true; }
            }
            return false;
        }
    }
}
