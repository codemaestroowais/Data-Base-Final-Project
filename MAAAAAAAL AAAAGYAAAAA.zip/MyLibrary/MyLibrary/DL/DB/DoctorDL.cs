﻿using MyLibrary.BL;
using MyLibrary.DL_Interface;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.DL.DB
{
    public class DoctorDL : IDoctor
    {
        private string conn = "Data Source=OWAIS\\SQLEXPRESS;Initial Catalog=SignInSignUp;Integrated Security=True";
        public DoctorDL(string conn)
        {
            this.conn = conn;
        }

        public bool AddDoctor(DoctorBL doctor)
        {
            string query = String.Format("Insert into Doctor(Name, Speciality) values('{0}','{1}')"
                , doctor.GetDoctorName(), doctor.GetDoctorSpeciality());
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int rows = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (rows > 0)
            {
                return true;
            }
            return false;
        }
        public List<DoctorBL> ViewDoctor()
        {
            List<DoctorBL> employ = new List<DoctorBL>();
            string query = "Select * from Doctor";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                DoctorBL doctor1 = new DoctorBL(Convert.ToString(reader["Name"]), Convert.ToString(reader["Speciality"]));
                employ.Add(doctor1);
            }
            reader.Close();
            sqlConnection.Close();
            return employ;
        }
    }
}
