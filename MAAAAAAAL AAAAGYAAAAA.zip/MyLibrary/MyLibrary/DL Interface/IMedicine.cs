﻿using MyLibrary.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLibrary.DL_Interface;

namespace MyLibrary.DL_Interface
{
    public interface IMedicine
    {
        //Add data into file
        bool AddMedicine(Medicines medicine);
        //View all data
        Medicines GetMedicine(int MedicineBatchNo);
        //View the list 
        List<Medicines> ViewMedicine();
        //Update the medicines
        bool UpdateMedicine(int MedicineBatchNo, Medicines medicine);
        //Remove the medicines
        bool RemoveMedicine(int MedicineBatchNo);
    }
}
