﻿using MyLibrary.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.DL_Interface
{
    public interface IAdmin
    {
        //This function can add beds data to database
        bool AddBed(int bed, string username);
        //This function is used to view the Beds added in database
        int GetBeds(string UserName);

    }
}
