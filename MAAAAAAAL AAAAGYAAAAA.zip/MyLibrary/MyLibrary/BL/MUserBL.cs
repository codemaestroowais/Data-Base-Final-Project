﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class MUserBL
    {
        //Attributes
        protected string Name;
        protected string Gender;
        protected string UserName;
        protected string Password;
        protected string Role;
        //Constructor
        public MUserBL() { }
        public MUserBL(string UserName, string Password)
        {
            this.UserName = UserName;
            this.Password = Password;
        }
        public MUserBL(string Name, string Gender, string UserName, string Password, string Role)
        {
            this.Name = Name;
            this.Gender = Gender;
            this.UserName = UserName;
            this.Password = Password;
            this.Role = Role;
        }
        //Setter
        public void SetUserName(string  UserName) { this.UserName = UserName; }
        public void SetPassword(string Password) { this.Password = Password; }
        public void SetGender(string Gender) {  this.Gender = Gender; }
        public void SetName(string Name) { this.Name = Name; }
        public void SetRole(string Role) {  this.Role = Role; }
        //Getter
        public string GetUserName() { return this.UserName;}
        public string GetGender() { return this.Gender;}
        public string GetRole() { return this.Role;}
        public string GetPassword() { return this.Password;}
        public string GetName() { return this.Name;}
        //Verifying Users
        bool IsAdmin() 
        {
            if (this.Role == "Admin")
                return true;
            return false;
        }
        bool IsPatient()
        {
            if(this.Role=="Patient")
                return true;
            return false;
        }
        bool IsPharmacist()
        {
            if(this.Role=="Pharmacist")
            {
                return true;
            }
            return false;
        }


    }
}
