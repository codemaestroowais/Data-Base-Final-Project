﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary.BL
{
    public class DoctorBL
    {
        //Attributes
        private string DoctorName;
        private string DoctorSpeciality;
        //Constructor
        public DoctorBL(string doctorName, string doctorSpeciality)
        {
            DoctorName = doctorName;
            DoctorSpeciality = doctorSpeciality;
        }
        //Setter
        public void SetDoctorName(string DoctorName) { this.DoctorName = DoctorName; }
        public void SetDoctorSpeciality(string DoctorSpeciality) { this.DoctorSpeciality = DoctorSpeciality; }
        //Getter
        public string GetDoctorName() { return this.DoctorName; }
        public string GetDoctorSpeciality() { return this.DoctorSpeciality; }
    }
}
